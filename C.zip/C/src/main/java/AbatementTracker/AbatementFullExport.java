package AbatementTracker;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AbatementFullExport {
    public static void Export() throws ClassNotFoundException {

        try {
            PrintWriter pw = new PrintWriter(
                    new File("C:\\Users\\Dell\\Downloads\\Tracker.csv"));

            StringBuilder sb = new StringBuilder();

            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@10.40.12.63:1521/dfsos", "mlgview", "mlgview123");

            System.out.println("Connection Created...");

            PreparedStatement ps = connection.prepareStatement("SELECT * from AbatementTrackerDummy");

            ResultSet rs = ps.executeQuery();

           sb.append("CONSUMER_NO");
			sb.append(",");

			sb.append("Send Date");
			sb.append(",");
			sb.append("Abatement Status");
			sb.append(",");
			sb.append("Pending With");
			sb.append(",");

			sb.append("Abated Amount");
			sb.append(",");
			sb.append("Abated Units");
			sb.append(",");
			sb.append("B80 Sumbit");
			sb.append(",");
			sb.append("B80 Approed");
			sb.append(",");
			sb.append("Forword To");
			sb.append(",");
		
			sb.append("Which AC Month");
                        sb.append(",");
			sb.append("Reason");
			sb.append("\r\n");

            while (rs.next()) {
                sb.append(rs.getString("CONSUMERNO"));
                sb.append(",");
                sb.append(rs.getString("SENTDATE"));
				sb.append(",");
				sb.append(rs.getString("ABETMENTSTATUS"));
				sb.append(",");
				sb.append(rs.getString("PENDINGOFFICER"));
				sb.append(",");

				sb.append(rs.getString("ABATEDAMOUNT"));
				sb.append(",");
				sb.append(rs.getString("ABATEDUNITS"));
				sb.append(",");
				sb.append(rs.getString("B80SUBMIT"));  
				sb.append(",");
				sb.append(rs.getString("B80APPROVED"));
				sb.append(",");
				sb.append(rs.getString("FORWARDTO"));
				sb.append(",");
				sb.append(rs.getString("ACMONTH"));
                                sb.append(",");
				sb.append(rs.getString("ABATEMENTREASON"));
				sb.append("\r\n");
            }

            pw.write(sb.toString());
            pw.close();
            System.out.println("CSV Generated...");

        } catch (SQLException e) {
            System.out.println("Database error:");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("File IO error:");
            e.printStackTrace();
        }
    }
}
